#include <stdio.h>
#include <stdlib.h>


int resourcesmenubar();
int khatianmenu();
int khatiantotto();
int mapmenu();
int maptotto();
int doliltotto();
void dropdownMenu();
void gotoxy(int x, int y);

void resourceManagementSystem() {
    int resourcermenu;

    do {
        system("cls");

        // Show resources menu
        resourcermenu = resourcesmenubar();

        if (resourcermenu == 1) { // Khatian menu
            int khatmenu;
            do {
                system("cls");
                khatmenu = khatianmenu(); // Khatian submenu
                if (khatmenu == 1) { // RS Khatian
                    int RSkhatiinfo;
                    do {
                        system("cls");
                        RSkhatiinfo = khatiantotto(); // RS Khatian info
                        if (RSkhatiinfo == 1) {
                            system("cls");
                            biroktikordropdown();

                        }

                    } while (RSkhatiinfo != 2);
                }
                else if (khatmenu == 2) { // BS Khatian
                    int BSkhatiinfo;
                    do {
                        system("cls");
                        BSkhatiinfo = khatiantotto(); // BS Khatian info
                        if (BSkhatiinfo == 1) {
                            system("cls");
                            biroktikordropdown();

                            gotoxy(60, 24);
                            gotoxy(60, 25);


                        }

                    } while (BSkhatiinfo != 2);
                }
            } while (khatmenu != 3);
        }
        else if (resourcermenu == 2) { // Map menu
            int mapsmenu;
            do {
                system("cls");
                mapsmenu = mapmenu(); // Map submenu
                if (mapsmenu == 1) { // RS Map
                    int mapsinfo;
                    do {
                        system("cls");
                        mapsinfo = maptotto(); // RS map info
                        if (mapsinfo == 1) {
                            system("cls");
                            biroktikordropdown();
                        }

                    } while (mapsinfo != 2);
                }
                else if (mapsmenu == 2) { // BS Map
                    int mapsinfo;
                    do {
                        system("cls");
                        mapsinfo = maptotto(); // BS map info
                        if (mapsinfo == 1) {
                            system("cls");
                            biroktikordropdown();
                        }

                    } while (mapsinfo != 2);
                }
            } while (mapsmenu != 3);
        }
        else if (resourcermenu == 3) { // Dolil menu
            int dolilinfo;
            do {
                system("cls");
                dolilinfo = doliltotto(); // Dolil info
                if (dolilinfo == 1) {
                    system("cls");
                    biroktikordropdown();
                }

            } while (dolilinfo != 2);
        }
    } while (resourcermenu != 4); // Exit when resource menu is 4 (Back)
}



