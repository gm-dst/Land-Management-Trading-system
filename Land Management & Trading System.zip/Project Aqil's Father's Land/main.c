#include<stdio.h>

int FstMenu(); /// First or opening menu;
void IDCopy(); /// User ID Copy;
void readFile1M(); /// READ File for first menu;
void writeFile1M(); /// WRITE file for first menu;
void readFile_Lawyers(); /// Lawyers
void LawyerInfo(); /// Lawyers
void readFile_Surveyor(); /// Surveyors
void SurveyorInfo(); /// Surveyors
void IptId(); /// User ID Signup;
int ChckId(); /// User ID Login;
int ScndMenu(); /// Second Menu;
int SrvceMenu(); /// Service menu;
int LBSll(); /// Land Buy or sell menu;
int LSI(); /// Land sell info menu;
void readFile_LSI(); /// READ File for Land sell info input;
void writeFile_LSI(); /// WRITE File for Land sell info input;
void Lndinsrt(); /// Land sell info input;
int LSDelete(); /// Land sell info delete;
void LBShow(); /// Land Buying shown fun.;
void LSShow(); /// Land selling shown fun.;
void resourceManagementSystem();
void Support();

int main()
{
    int Fst;
    do{
        system("cls");
        Fst = FstMenu();
        if(Fst == 1){
            system("cls");
            int f = ChckId();
            if(f == 1){
                system("cls");
                gotoxy(67,18);
                printf("Logging in");
                for(int i=0,j=77;i<4;i++,j++){
                    delay(2);
                    gotoxy(j,18);
                    printf(".");
                }
                IDCopy();
                int Scnd;
                do{
                    system("cls");
                    Scnd = ScndMenu();
                    if(Scnd == 1){
                        system("cls");
                        int Svc;
                        do{
                            system("cls");
                            Svc = SrvceMenu();
                            if(Svc == 1){
                                int LBS;
                                do{
                                    system("cls");
                                    LBS = LBSll();
                                    if(LBS == 1){
                                        system("cls");
                                        char Ent;
                                        do{
                                            LBShow();
                                            getchar();
                                            scanf("%c", &Ent);
                                        } while(Ent!='\n');
                                    }
                                    else if(LBS == 2){
                                        int Lsi;
                                        do{
                                            system("cls");
                                            Lsi = LSI();
                                            if(Lsi == 1){
                                                system("cls");
                                                Lndinsrt();
                                                gotoxy(60,32);
                                                printf("Land data is now posted and available to buyer!");
                                                gotoxy(60,34);
                                                printf("Click Enter to go back");
                                                gotoxy(60,35);

                                                char Ent;
                                                getchar();
                                                do{
                                                    scanf("%c", &Ent);
                                                } while(Ent!='\n');
                                            }
                                            else if(Lsi == 2){
                                                system("cls");
                                                int Dback = LSDelete();

                                                if(Dback==-1){

                                                }
                                                else{
                                                    Dback++;
                                                    system("cls");
                                                    gotoxy(67,18);
                                                    printf("Post no. %d deleted successfully!", Dback);
                                                    char Ent;
                                                    do{

                                                        getchar();
                                                        scanf("%c", &Ent);
                                                    } while(Ent!='\n');
                                                }
                                            }
                                            else if(Lsi == 3){
                                                system("cls");
                                                char Ent;
                                                do{
                                                    LSShow();
                                                    getchar();
                                                    scanf("%c", &Ent);
                                                } while(Ent!='\n');
                                            }

                                        } while(Lsi!=4);
                                    }
                                } while(LBS!=3);

                            }
                            else if(Svc == 2){
                                system("cls");
                                char Ent;
                                do{
                                    LawyerInfo();
                                    getchar();
                                    scanf("%c", &Ent);
                                } while(Ent!='\n');
                            }
                            else if(Svc == 3){
                                system("cls");
                                char Ent;
                                do{
                                    SurveyorInfo();
                                    getchar();
                                    scanf("%c", &Ent);
                                } while(Ent!='\n');
                            }
                        } while(Svc!=4);
                    }
                    else if(Scnd == 2){
                        resourceManagementSystem();
                    }
                    else if(Scnd == 3){

                        system("cls");
                        char Ent;
                        do{
                            Support();
                            getchar();
                            scanf("%c", &Ent);
                        } while(Ent!='\n');
                    }
                } while(Scnd!=4);
            }
            else{
                gotoxy(67,20);
                printf("Incorrect User ID or password\n");
                return 1;
            }

        }
        else if(Fst == 2){
            system("cls");
            IptId();
            gotoxy(67,20);
            printf("Signup Successful\n");
            gotoxy(67,22);
            printf("Click Enter to go back to main menu!");
            gotoxy(67,23);
            while (getchar() != '\n');
        }
    } while(Fst!=3);
    return 0;
}
