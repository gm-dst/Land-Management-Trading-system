//#include<stdio.h>
//
//struct lndinfo
//{
//    char SllrName[80],Adrs[80],CnctNmbr[15],Eml[50];
//    char ArSze[30],RS[20],BS[20],Img[100],Prce[50];
//    char Spsfeat[100],Dscrp[150];
//};
//struct lndinfo b[100];
//int p,StrdId,p_k;
//
//char ID[50],t[5]=".txt";
//
//struct usr
//{
//    char pss[50];
//    char id[50];
//};
//struct usr a[20];
//int n;
//
//struct lawyerInfo
//{
//    char Name[100],Cnct[40],Location[150];
//};
//struct lawyerInfo law[100];
//int q;

/////Opening menu;
//int FstMenu()
//{
//    int m;
//
//    gotoxy(67,17);
//    printf("1. User login\n");
//
//    gotoxy(67,18);
//    printf("2. User signup\n");
//
//    gotoxy(67,19);
//    printf("3. Quit\n");
//
//    gotoxy(67,21);
//    printf("Choose option: ");
//    scanf("%d", &m);
//    return m;
//}
//
/////Check Id Function;
//int ChckId() {
//    int f = 0;
//    char id1[10], pss1[20];
//    readFile1M();
//
//    gotoxy(67,17);
//    printf("User ID: ");
//
//    getchar(); // Consumes the leftover newline character '\n';
//    scanf("%[^\n]", id1);
//
//    gotoxy(67,18);
//    printf("Password: ");
//
//    getchar();
//    scanf("%[^\n]", pss1);
//
//    for(int i = 0; i < n; i++){
//        if(strcmp(a[i].id, id1) == 0 && strcmp(a[i].pss, pss1) == 0){
//            f = 1;
//            StrdId = i;
//            break;
//        }
//    }
//    return f;
//}
//
/////User information signup function;
//void IptId()
//{
//    int i,h,g;
//    char temp_id[50];
//    readFile1M();
//    getchar();
//    do{
//        system("cls");
//        h=0;
//        g=0;
//
//        gotoxy(67, 17);
//        printf("User ID: ");
//
//        fgets(temp_id, sizeof(temp_id), stdin);
//        temp_id[strcspn(temp_id, "\n")] = '\0';
//
//        int c = strlen(temp_id);
//        if(c < 3){
//            g = 1;
//        }
//        else{
//            for(i = 0; i < n; i++){
//                if(strcmp(temp_id, a[i].id) == 0){
//                    h = 1;
//                    break;
//                }
//            }
//        }
//
//        if(g == 1){
//            gotoxy(67, 19);
//            printf("User ID must contain at least 3 characters!");
//            gotoxy(67, 21);
//            printf("CLICK ENTER TO TRY AGAIN!");
//            gotoxy(67, 22);
//            while (getchar() != '\n');
//        }
//        else if(h == 1){
//            gotoxy(67, 19);
//            printf("User ID already exists! Try a different User ID!");
//            gotoxy(67, 21);
//            printf("CLICK ENTER TO TRY AGAIN!");
//            gotoxy(67, 22);
//            while (getchar() != '\n');
//        }
//
//    } while (h != 0 || g != 0);
//
//    strcpy(a[n].id, temp_id);
//
//    int InvPss;
//    do{
//        InvPss=0;
//
//        gotoxy(67,18);
//        printf("Password: ");
//        gotoxy(77, 18);
//        printf("                         ");
//        gotoxy(77, 18);
//        fgets(temp_id, sizeof(temp_id), stdin);
//        temp_id[strcspn(temp_id, "\n")] = '\0';
//
//        int c = strlen(temp_id);
//        if(c<4){
//            InvPss=1;
//            gotoxy(67, 20);
//            printf("Password must be at least 4 characters or numbers!");
//            gotoxy(67, 22);
//            printf("CLICK ENTER TO TRY AGAIN!");
//            gotoxy(67, 23);
//            while (getchar() != '\n');
//        }
//        if(InvPss == 1){
//            gotoxy(67, 20);
//            printf("                                                   ");
//            gotoxy(67, 22);
//            printf("                                           ");
//        }
//
//    } while(InvPss!=0);
//
//    strcpy(a[n].pss, temp_id);
//    n++;
//
//    writeFile1M();
//}
//
/////Second Menu;
//int ScndMenu()
//{
//    int m;
//
//    gotoxy(67,17);
//    printf("1. Services\n");
//
//    gotoxy(67,18);
//    printf("2. Resources\n");
//
//    gotoxy(67,19);
//    printf("3. Support\n");
//
//    gotoxy(67,20);
//    printf("4. Logout\n");
//
//    gotoxy(67,22);
//    printf("Choose option: ");
//    scanf("%d", &m);
//    return m;
//}
//
/////Service Menu;
//int SrvceMenu()
//{
//    int m;
//
//    gotoxy(67,17);
//    printf("1. Land Buy or Sell");
//
//    gotoxy(67,18);
//    printf("2. Hire Lawyers");
//
//    gotoxy(67,19);
//    printf("3. Hire Surveyors");
//
//    gotoxy(67,20);
//    printf("4. Back");
//
//    gotoxy(67,22);
//    printf("Choose option: ");
//    scanf("%d", &m);
//    return m;
//}
//
/////Land Buy Sell Menu;
//int LBSll()
//{
//    int m;
//
//    gotoxy(67,17);
//    printf("1. Buy Land");
//
//    gotoxy(67,18);
//    printf("2. Sell Land");
//
//    gotoxy(67,19);
//    printf("3. Back");
//
//    gotoxy(67,21);
//    printf("Choose option: ");
//    scanf("%d", &m);
//    return m;
//}
//
/////Land Buyer interface;
//void LBShow()
//{
//    readFile1M();
//    int i,j,d,g=0;
//    FILE *f;
//
//    for(i=0; i < n; i++){
//        strcpy(ID,a[i].id);
//        strcat(ID,t);
//        f = fopen(ID, "r");
//        if(f == 0){
//            continue;
//        }
//
//        fscanf(f, "%d", &p);
//        d=g+p;
//
//        for(j = g; j < d; j++) {
//            fscanf(f, " %[^\n]", b[j].SllrName);
//
//            fscanf(f, " %[^\n]", b[j].Adrs);
//            fscanf(f, " %[^\n]", b[j].CnctNmbr);
//            fscanf(f, " %[^\n]", b[j].Eml);
//            fscanf(f, " %[^\n]", b[j].ArSze);
//            fscanf(f, " %[^\n]", b[j].RS);
//            fscanf(f, " %[^\n]", b[j].BS);
//            fscanf(f, " %[^\n]", b[j].Img);
//            fscanf(f, " %[^\n]", b[j].Prce);
//            fscanf(f, " %[^\n]", b[j].Spsfeat);
//            fscanf(f, " %[^\n]", b[j].Dscrp);
//        }
//        g=g+p;
//
//        fclose(f);
//    }
//
//    int k=0,l=1;
//    for(i=0; i < d; i++,l++){
//        gotoxy(16,k);
//        printf("(%d)", l);
//        gotoxy(20,k);
//        printf("Name: %s  ", b[i].SllrName);
//        printf("Address: %s  ", b[i].Adrs);
//        printf("Contact: %s  ", b[i].CnctNmbr);
//        printf("Email: %s", b[i].Eml);
//        k+=2;
//        gotoxy(20,k);
//        printf("RS Khatian no. & dag: %s  ", b[i].RS);
//        printf("BS Khatian no. & dag: %s", b[i].BS);
//        k+=2;
//        gotoxy(20,k);
//        printf("Image link: %s  ", b[i].Img);
//        printf("Area Size: %s  ", b[i].ArSze);
//        printf("Price: %s", b[i].Prce);
//        k+=2;
//        gotoxy(20,k);
//        printf("Special features: %s", b[i].Spsfeat);
//        k+=2;
//        gotoxy(20,k);
//        printf("Description: %s", b[i].Dscrp);
//        k+=2;
//        gotoxy(20,k);
//        printf("---------------------------------------------------------------------------------------------------------------------------------");
//        k+=3;
//    }
//}
//
/////Land Information Menu;
//int LSI()
//{
//    int m;
//
//    gotoxy(67,17);
//    printf("1. Insert New Land Information");
//
//    gotoxy(67,18);
//    printf("2. Delete Land Information");
//
//    gotoxy(67,19);
//    printf("3. Show All Land information");
//
//    gotoxy(67,20);
//    printf("4. Back");
//
//    gotoxy(67,22);
//    printf("Choose option: ");
//    scanf("%d", &m);
//    return m;
//}
//
//
/////Land Selling Information INPUT Function;
//void Lndinsrt()
//{
//    readFile_LSI();
//
//    gotoxy(60,10);
//    printf("Name: ");
//    getchar();
//    scanf("%[^\n]", b[p].SllrName);
//
//    gotoxy(60,12);
//    printf("Address: ");
//    getchar();
//    scanf("%[^\n]", b[p].Adrs);
//
//    gotoxy(60,14);
//    printf("Contact Number: ");
//    getchar();
//    scanf("%[^\n]", b[p].CnctNmbr);
//
//    gotoxy(60,16);
//    printf("Email: ");
//    getchar();
//    scanf("%[^\n]", b[p].Eml);
//
//    gotoxy(60,18);
//    printf("Area Size: ");
//    getchar();
//    scanf("%[^\n]", b[p].ArSze);
//
//    gotoxy(60,20);
//    printf("RS Khatian no. & dag: ");
//    getchar();
//    scanf("%[^\n]", b[p].RS);
//
//    gotoxy(60,22);
//    printf("BS Khatian no. & dag: ");
//    getchar();
//    scanf("%[^\n]", b[p].BS);
//
//    gotoxy(60,24);
//    printf("Image link: ");
//    getchar();
//    scanf("%[^\n]", b[p].Img);
//
//    gotoxy(60,26);
//    printf("Price: ");
//    getchar();
//    scanf("%[^\n]", b[p].Prce);
//
//    gotoxy(60,28);
//    printf("Special features: ");
//    getchar();
//    scanf("%[^\n]", b[p].Spsfeat);
//
//    gotoxy(60,30);
//    printf("Description: ");
//    getchar();
//    scanf("%[^\n]", b[p].Dscrp);
//
//    p++;
//
//    writeFile_LSI();
//}
//
//
//
//
//
/////Land seller user Land information show function;
//void LSShow()
//{
//    readFile_LSI();
//    int i,k=0,j=1;
//    if(p==0){
//        gotoxy(60,20);
//        printf("No information found!");
//    }
//    for(i=0; i < p; i++,j++){
//        gotoxy(16,k);
//        printf("(%d)", j);
//        gotoxy(20,k);
//        printf("Name: %s  ", b[i].SllrName);
//        printf("Address: %s  ", b[i].Adrs);
//        printf("Contact: %s  ", b[i].CnctNmbr);
//        printf("Email: %s", b[i].Eml);
//        k+=2;
//        gotoxy(20,k);
//        printf("RS Khatian no. & dag: %s  ", b[i].RS);
//        printf("BS Khatian no. & dag: %s", b[i].BS);
//        k+=2;
//        gotoxy(20,k);
//        printf("Image link: %s  ", b[i].Img);
//        printf("Area Size: %s  ", b[i].ArSze);
//        printf("Price: %s", b[i].Prce);
//        k+=2;
//        gotoxy(20,k);
//        printf("Special features: %s", b[i].Spsfeat);
//        k+=2;
//        gotoxy(20,k);
//        printf("Description: %s", b[i].Dscrp);
//        k+=2;
//        gotoxy(20,k);
//        printf("---------------------------------------------------------------------------------------------------------------------------------");
//        k+=3;
//    }
//    p_k=k;
//
//}
//
//
/////Land sell info deletion function;
//int LSDelete()
//{
//    int i,m=-1;
//    readFile_LSI();
//    if(p==0){
//        gotoxy(60,20);
//        printf("No information found!");
//        char Ent;
//        do{
//
//            getchar();
//            scanf("%c", &Ent);
//        } while(Ent!='\n');
//        return m;
//    }
//    else{
//        LSShow();
//        do{
//            gotoxy(20,p_k);
//            printf("ENTER THE POST NO. or Press '0' to go back: ");
//            scanf("%d", &m);
//            m--;
//            if(m<-1 || m>p-1){
//                int f=p_k+22,g=p_k+1;
//                gotoxy(20,g);
//                printf("Invalid Post No.");
//                gotoxy(64,p_k);
//                printf("          ");
//            }
//        } while(m<-1 || m>p-1);
//
//        if(m>-1){
//            for(i=m; i<p-1; i++){
//                b[i] = b[i+1];
//            }
//
//            p--;
//            writeFile_LSI();
//            return m;
//        }
//        else{
//            return m;
//        }
//    }
//}
//
///// Lawyers;
//void LawyerInfo()
//{
//    readFile_Lawyers();
//
//    int i,k=0;
//    for(i=0; i < q; i++){
//
//        gotoxy(25,k);
//        printf("%s", law[i].Name);
//
//        k+=2;
//        gotoxy(25,k);
//        printf("%s", law[i].Cnct);
//
//        k+=2;
//        gotoxy(25,k);
//        printf("%s", law[i].Location);
//
//        k+=2;
//        printf("-------------------------------------");
//    }
//}
