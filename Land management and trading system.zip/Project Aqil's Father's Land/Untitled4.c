///resourcemenu-aqil;


int resourcesmenubar()
{
    int m;

    gotoxy(67,17);
    printf("1. Khatian\n");

    gotoxy(67,18);
    printf("2. Map\n");

    gotoxy(67,19);
    printf("3. Dolil\n");

    gotoxy(67,20);
    printf("4. Back\n");

    gotoxy(67,22);
    printf("Choose option: ");
    scanf("%d", &m);
    return m;
}


///khatian Menu;
int khatianmenu()
{
    int m;

    gotoxy(67,17);
    printf("1. RS Khatian");

    gotoxy(67,18);
    printf("2. BS Khatian");

    gotoxy(67,19);
    printf("3. Back");

    gotoxy(67,21);
    printf("Choose option: ");
    scanf("%d", &m);
    return m;
}



///khatian totto Menu;
int khatiantotto()
{
    int m;

    gotoxy(67,17);
    printf("1.Press 1 to Enter the Khatian Details");
    gotoxy(67,19);
    printf("2. Back");

    gotoxy(67,22);
    printf("Choose option: ");
    scanf("%d", &m);
    return m;
}


///map Menu;
int mapmenu()
{
    int m;

    gotoxy(67,17);
    printf("1. RS Map");

    gotoxy(67,18);
    printf("2. BS Map");

    gotoxy(67,19);
    printf("3. Back");

    gotoxy(67,21);
    printf("Choose option: ");
    scanf("%d", &m);
    return m;
}


///map totto Menu;
int maptotto()
{
    int m;

    gotoxy(67,17);
    printf("1.Press 1 to Enter the Map Details");
    gotoxy(67,19);
    printf("2. Back");

    gotoxy(67,22);
    printf("Choose option: ");
    scanf("%d", &m);
    return m;
}

int doliltotto()
{
    int m;

    gotoxy(67,17);
    printf("1.Press 1 to Enter the Dolil Details");
    gotoxy(67,19);
    printf("2. Back");

    gotoxy(67,22);
    printf("Choose option: ");
    scanf("%d", &m);
    return m;
}


int ZilaMenu()///ctg division er zilagulo
{
    int m;

    gotoxy(67,17);
    printf("1. Chattogram\n");

    gotoxy(67,18);
    printf("2. Cox's Bazar\n");

    gotoxy(67,19);
    printf("3. Noakhali\n");

    gotoxy(67,20);
    printf("4. Comilla\n");

    gotoxy(67,21);
    printf("5. Back");

    gotoxy(67,22);
    printf("Choose option: ");
    scanf("%d", &m);
    return m;
}

int ctgupzilaorthana()
{
///ctg zilar upazilagulo
    int m;

    gotoxy(67,17);
    printf("1. Sandip\n");

    gotoxy(67,18);
    printf("2. Patia\n");

    gotoxy(67,19);
    printf("3. Banshkhali\n");

    gotoxy(67,20);
    printf("4. Anwara\n");
    gotoxy(67,21);
    printf("5. Back");

    gotoxy(67,22);
    printf("Choose option: ");
    scanf("%d", &m);
    return m;
}



int coxupzilaorthana()
{
///cox's bazar zilar upazilagulo
    int m;

    gotoxy(67,17);
    printf("1. Cox's Bazar Sadar\n");

    gotoxy(67,18);
    printf("2. Maheshkhali\n");

    gotoxy(67,19);
    printf("3. Pekua\n");

    gotoxy(67,20);
    printf("4. Teknaf\n");
    gotoxy(67,21);
    printf("5. Back");
    gotoxy(67,22);
    printf("Choose option: ");
    scanf("%d", &m);
    return m;
}


int noakhaliupzilaorthana()
{
///noakhali zilar upazilagulo
    int m;

    gotoxy(67,17);
    printf("1. Noakhali Sadar\n");

    gotoxy(67,18);
    printf("2. Hatia\n");

    gotoxy(67,19);
    printf("3. Begumganj\n");

    gotoxy(67,20);
    printf("4. Chatkhil\n");
    gotoxy(67,21);
    printf("5. Back");
    gotoxy(67,22);
    printf("Choose option: ");
    scanf("%d", &m);
    return m;
}

int comillarupzilaorthana()
{
///rangamati zilar upazilagulo
    int m;

    gotoxy(67,17);
    printf("1. Chouddagram\n");

    gotoxy(67,18);
    printf("2. Debidwar\n");
    gotoxy(67,19);
    printf("3. Homna\n");
    gotoxy(67,20);
    printf("4. Laksam\n");
    gotoxy(67,21);
    printf("5. Back");
    gotoxy(67,22);
    printf("Choose option: ");
    scanf("%d", &m);
    return m;
}



int sandipermouza()
{
///rangamati zilar upazilagulo
    int m;

    gotoxy(67,17);
    printf("1. Ruhina\n");

    gotoxy(67,18);
    printf("2. Azimpur\n");

    gotoxy(67,19);
    printf("3. Harishpur\n");

    gotoxy(67,20);
    printf("4. Katgar\n");
    gotoxy(67,21);
    printf("5. Back");
    gotoxy(67,22);

    printf("Choose option: ");
    scanf("%d", &m);
    return m;
}

int patiarmouza()
{
    int m;

    gotoxy(67,17);
    printf("1. Mohira\n");

    gotoxy(67,18);
    printf("2. Jiri\n");

    gotoxy(67,19);
    printf("3. Chafra\n");

    gotoxy(67,20);
    printf("4. Korol\n");
    gotoxy(67,21);
    printf("5. Back");
    gotoxy(67,22);
    printf("Choose option: ");
    scanf("%d", &m);
    return m;
}

int anwararmouza()
{
int m;
    gotoxy(67,17);
    printf("1. Badalpura\n");

    gotoxy(67,18);
    printf("2. Rangadia\n");

    gotoxy(67,19);
    printf("3. Bandar\n");

    gotoxy(67,20);
    printf("4. Chapatali\n");
    gotoxy(67,21);
    printf("5. Back");
    gotoxy(67,22);
    printf("Choose option: ");
    scanf("%d", &m);
    return m;


}
int bashkhalirmouza()
{    int m;

    gotoxy(67,17);
    printf("1. Rata\n");

    gotoxy(67,18);
    printf("2. Banigram\n");

    gotoxy(67,19);
    printf("3. Baharchara\n");

    gotoxy(67,20);
    printf("4. Ilsha\n");
    gotoxy(67,21);
    printf("5. Back");
    gotoxy(67,22);
    printf("Choose option: ");
    scanf("%d", &m);
    return m;


}
int coxsbazaradarermouza()
{
    int m;

    gotoxy(67,17);
    printf("1. Eidghao\n");

    gotoxy(67,18);
    printf("2. Napitkhali\n");

    gotoxy(67,19);
    printf("3. Boalkhali\n");

    gotoxy(67,20);
    printf("4. Varuakhali\n");
    gotoxy(67,21);
    printf("5. Back");
    gotoxy(67,22);
    printf("Choose option: ");
    scanf("%d", &m);
    return m;
}
int maheshkhalirmouza()
{
    int m;

    gotoxy(67,17);
    printf("1. Panirchhara\n");

    gotoxy(67,18);
    printf("2. Shaplapur\n");

    gotoxy(67,19);
    printf("3. Kutubjum\n");

    gotoxy(67,20);
    printf("4. Ghativanga\n");
    gotoxy(67,21);
    printf("5. Back");
    gotoxy(67,22);
    printf("Choose option: ");
    scanf("%d", &m);
    return m;
}

int pekuarmouza()
{
    int m;

    gotoxy(67,17);
    printf("1. Battali\n");

    gotoxy(67,18);
    printf("2. Shilkhali\n");

    gotoxy(67,19);
    printf("3. Rajakhali\n");

    gotoxy(67,20);
    printf("4. Hoanak\n");
    gotoxy(67,21);
    printf("5. Back");
    gotoxy(67,22);
    printf("Choose option: ");
    scanf("%d", &m);
    return m;
}

int teknafermouza()
{
    int m;

    gotoxy(67,17);
    printf("1. Sabrang\n");

    gotoxy(67,18);
    printf("2. Shah Parir Dip\n");

    gotoxy(67,19);
    printf("3. Boro Dail\n");

    gotoxy(67,20);
    printf("4. Uttar Hnila\n");
    gotoxy(67,21);
    printf("5. Back");
    gotoxy(67,22);
    printf("Choose option: ");
    scanf("%d", &m);
    return m;
}

int noakhalisadarermouza()
{
    int m;

    gotoxy(67,17);
    printf("1. Obhirampur\n");

    gotoxy(67,18);
    printf("2. Nandanpur\n");

    gotoxy(67,19);
    printf("3. Jamalpur\n");

    gotoxy(67,20);
    printf("4. Panditpur\n");
    gotoxy(67,21);
    printf("5. Back");
    gotoxy(67,22);
    printf("Choose option: ");
    scanf("%d", &m);
    return m;
}
int hatiarrmouza()
{
    int m;

    gotoxy(67,17);
    printf("1. Char Ishwar Ray\n");

    gotoxy(67,18);
    printf("2. Suryamukhi\n");

    gotoxy(67,19);
    printf("3. Shunnochar\n");

    gotoxy(67,20);
    printf("4. Char Hair\n");
    gotoxy(67,21);
    printf("5. Back");
    gotoxy(67,22);
    printf("Choose option: ");
    scanf("%d", &m);
    return m;
}

int begumganjermouza()
{
    int m;

    gotoxy(67,17);
    printf("1. Betuabeg\n");

    gotoxy(67,18);
    printf("2. Quaria\n");

    gotoxy(67,19);
    printf("3. Mamudpur\n");

    gotoxy(67,20);
    printf("4. Bhababhadri\n");
    gotoxy(67,21);
    printf("5. Back");
    gotoxy(67,22);
    printf("Choose option: ");
    scanf("%d", &m);
    return m;
}
int chatkhilermouza()
{
    int m;

    gotoxy(67,17);
    printf("1. Manikpur\n");

    gotoxy(67,18);
    printf("2. Manoharpur\n");

    gotoxy(67,19);
    printf("3. Hirapur\n");

    gotoxy(67,20);
    printf("4. Palla\n");
    gotoxy(67,21);
    printf("5. Back");
    gotoxy(67,22);
    printf("Choose option: ");
    scanf("%d", &m);
    return m;
}
///chouddagram,debidwar,homna,laksam
int chouddhagramermouza()
{
    int m;

    gotoxy(67,17);
    printf("1. Katalia\n");

    gotoxy(67,18);
    printf("2. Dharmapur\n");

    gotoxy(67,19);
    printf("3. Hosenpur\n");

    gotoxy(67,20);
    printf("4. Katalia\n");
    gotoxy(67,21);
    printf("5. Back");
    gotoxy(67,22);
    printf("Choose option: ");
    scanf("%d", &m);
    return m;
}
int debidwarermouza()
{
    int m;

    gotoxy(67,17);
    printf("1. Raja Khan Char\n");

    gotoxy(67,18);
    printf("2. Kanibil\n");

    gotoxy(67,19);
    printf("3. Gopal Nagar\n");

    gotoxy(67,20);
    printf("4. Mugsar\n");
    gotoxy(67,21);
    printf("5. Back");
    gotoxy(67,22);
    printf("Choose option: ");
    scanf("%d", &m);
    return m;
}
int homnarmouza()
{
    int m;

    gotoxy(67,17);
    printf("1. Mahishmari\n");

    gotoxy(67,18);
    printf("2. Jaydebpur\n");

    gotoxy(67,19);
    printf("3. Bijoynagar\n");

    gotoxy(67,20);
    printf("4. Nayachar\n");
    gotoxy(67,21);
    printf("5. Back");
    gotoxy(67,22);
    printf("Choose option: ");
    scanf("%d", &m);
    return m;
}
int lakshamermouza()
{
    int m;

    gotoxy(67,17);
    printf("1. Kapastala\n");

    gotoxy(67,18);
    printf("2. Bijra\n");

    gotoxy(67,19);
    printf("3. Joyisree\n");

    gotoxy(67,20);
    printf("4. Panchpara\n");
    gotoxy(67,21);
    printf("5. Back");
    gotoxy(67,22);
    printf("Choose option: ");
    scanf("%d", &m);
    return m;
}


int biroktikordropdown()
{
    int zila;
    do
    {
        system("cls");
        zila=ZilaMenu();
        if(zila==1)
        {


            int ctgthana;


            ///chattogram zilar thanagulo dekhay/print koray dilo
            ///ekhon amader kaj holo chattogram zilar upazilla gulor input neya ba back neya er jonno lagbe do while
            do
            {

                system("cls");
                ctgthana=ctgupzilaorthana();
                ///ekhon dekhbo zila1manectgzila ei variable er diff maner jonno different condition open hobe abar
                if(ctgthana==1)
                {

                    system("cls");

                    int Sandipermouzaa;



                    ///manesandipselecthoise
                    do
                    {
//

                        Sandipermouzaa=sandipermouza();


                        if(Sandipermouzaa==1)
                        {

                            gotoxy(67,24);

                            printf("Your document-link of Ruhina is given below");

                            gotoxy(67,25);
                            printf("Link: drive.google.com/ruhina");

                        }
                        else if(Sandipermouzaa==2)
                        {
                            gotoxy(67,24);
                            printf("Your document-link of Azimpur is given below");
                            gotoxy(67,25);

                            printf("Link: drive.google.com/Azimpur");
                        }
                        else if(Sandipermouzaa==3)
                        {
                            gotoxy(67,24);
                            printf("Your document-link of Harishpur is given below");

                            gotoxy(67,25);
                            printf("Link: drive.google.com/Harishpur");
                        }
                        else if(Sandipermouzaa==4)
                        {
                            gotoxy(67,24);
                            printf("Your document-link of Katgar is given below");
                            gotoxy(67,25);

                            printf("drive.google.com/Katgar");
                        }

                    }
                    while(Sandipermouzaa!=5);

                }
                else if(ctgthana==2)
                {
                    system("cls");
                    int Patiarmouza;
                    do
                    {

                        Patiarmouza=patiarmouza();
                        if(Patiarmouza==1)
                        {
                            gotoxy(67,24);
                            printf("Your document-link of Mohira is given below");

                            gotoxy(67,25);
                            printf("drive.google.com/mohira");

                        }
                        else if(Patiarmouza==2)
                        {
                            gotoxy(67,24);
                            printf("Your document-link of Jiri is given below");

                            gotoxy(67,25);
                            printf("drive.google.com/Jiri");
                        }
                        else if(Patiarmouza==3)
                        {
                            gotoxy(67,24);
                            printf("Your document-link of Chafra is given below");
                            gotoxy(67,25);

                            printf("drive.google.com/Chafra");
                        }
                        else if(Patiarmouza==4)
                        {
                            gotoxy(67,24);
                            printf("Your document-link of Korol is given below");



                            gotoxy(67,25);
                            printf("drive.google.com/Korol");
                        }
                    }
                    while(Patiarmouza!=5);
                    ///mane patia selected
                }
                else if(ctgthana==3)
                {
                    system("cls");
                    ///mane banshkhali selected
                    int BanshkhalirMouza;
                    do
                    {



                        BanshkhalirMouza=bashkhalirmouza();
                        if(BanshkhalirMouza==1)
                        {

                            gotoxy(67,24);
                            printf("Your document-link of Rataip is given below");
                            gotoxy(67,25);
                            printf("drive.google.com/Rataip");
                        }
                        else if(BanshkhalirMouza==2)
                        {
                            gotoxy(67,24);
                            printf("Your document-link of Banigram is given below");
                            gotoxy(67,25);
                            printf("drive.google.com/Banigram");
                        }
                        else if(BanshkhalirMouza==3)
                        {
                            gotoxy(67,24);
                            printf("Your document-link of Baharchara is given below");
                            gotoxy(67,25);
                            printf("drive.google.com/Baharchara");
                        }
                        else if(BanshkhalirMouza==4)
                        {
                            gotoxy(67,24);
                            printf("Your document-link of Ilshaa is given below");
                            gotoxy(67,25);
                            printf("drive.google.com/Ilshaa");
                        }


                    }
                    while(BanshkhalirMouza!=5);

                }
                else if(ctgthana==4)
                {
                    system("cls");
                    ///mane anwara selected
                    int Anwaramouza;
                    do
                    {

                        Anwaramouza=anwararmouza();
                        if(Anwaramouza==1)
                        {
                            gotoxy(67,24);
                            printf("Your document-link of Badalpura is given below");
                            gotoxy(67,25);
                            printf("drive.google.com/Badalpura");
                        }
                        else if(Anwaramouza==2)
                        {
                            gotoxy(67,24);
                            printf("Your document-link of Rangadia is given below");
                            gotoxy(67,25);
                            printf("drive.google.com/Rangadia");
                        }
                        else if(Anwaramouza==3)
                        {
                            gotoxy(67,24);
                            printf("Your document-link of Bandarhali is given below");
                            gotoxy(67,25);
                            printf("drive.google.com/Bandarhali");
                        }
                        else if(Anwaramouza==4)
                        {
                            gotoxy(67,24);
                            printf("Your document-link of Chapatali is given below");
                            gotoxy(67,25);
                            printf("drive.google.com/Chapatali");
                        }


                    }

                    while(Anwaramouza!=5);
                }

            }
            while(ctgthana!=5);
        }

        else if(zila==2)
        {

            int Coxthana;

            do   ///ei do-while upazila theke back korabe
            {
                system("cls");
                Coxthana=coxupzilaorthana();
                if (Coxthana==1)
///manecoxupazilarthanagular1nocoxssadarselect
                {
                    system("cls");

                    ///manecoxbazarsadar selected

                    int coxsadarermouza;
                    do
                    {

                        coxsadarermouza=coxsbazaradarermouza();
                        if(coxsadarermouza==1)
                        {
                            gotoxy(67,24);
                            printf("Your document-link of Eidghao is given below");
                            gotoxy(67,25);
                            printf("drive.google.com/Eidghao");
                        }
                        else if(coxsadarermouza==2)
                        {
                            gotoxy(67,24);
                            printf("Your document-link of Napitkhali is given below");
                            gotoxy(67,25);
                            printf("drive.google.com/Napitkhali");
                        }
                        else if(coxsadarermouza==3)
                        {
                            gotoxy(67,24);
                            printf("Your document-link of Boalkhali is given below");
                            gotoxy(67,25);
                            printf("drive.google.com/Boalkhali");
                        }
                        else if(coxsadarermouza==4)
                        {
                            gotoxy(67,24);
                            printf("Your document-link of Varulkhali is given below");
                            gotoxy(67,25);
                            printf("drive.google.com/Varuakhali");
                        }


                    }
                    while(coxsadarermouza!=5);


                }

                else if(Coxthana==2)  ///maheshkhali
                {

                    system("cls");
                    int maheshmouza;
                    do
                    {

                        maheshmouza=maheshkhalirmouza();
                        if(maheshmouza==1)
                        {
                            gotoxy(67,24);
                            printf("Your document-link of Panirchhara is given below");
                            gotoxy(67,25);
                            printf("drive.google.com/Panirchhara");
                        }
                        else if(maheshmouza==2)
                        {
                            gotoxy(67,24);
                            printf("Your document-link of Shaplapur is given below");
                            gotoxy(67,25);
                            printf("drive.google.com/Shaplapur");
                        }
                        else if(maheshmouza==3)
                        {
                            gotoxy(67,24);
                            printf("Your document-link of Kutubjum is given below");
                            gotoxy(67,25);
                            printf("drive.google.com/Kutubjum");
                        }
                        else if(maheshmouza==4)
                        {
                            gotoxy(67,24);
                            printf("Your document-link of Ghativanga is given below");

                            gotoxy(67,25);
                            printf("drive.google.com/Ghativanga");
                        }

                    }
                    while(maheshmouza!=5);
                }
                else if(Coxthana==3)
                {
                    system("cls");
                    int pekuamouzaV;
                    do
                    {

                        pekuamouzaV=pekuarmouza();
                        if(pekuamouzaV==1)
                        {
                            gotoxy(67,24);
                            printf("Your document-link of Battali is given below");
                            gotoxy(67,25);
                            printf("drive.google.com/Battali");
                        }
                        else if(pekuamouzaV==2)
                        {
                            gotoxy(67,24);
                            printf("Your document-link of Shilkhali is given below");
                            gotoxy(67,25);
                            printf("drive.google.com/Shilkhali");
                        }
                        else if(pekuamouzaV==3)
                        {
                            gotoxy(67,24);
                            printf("Your document-link of Rajakhali is given below");
                            gotoxy(67,25);
                            printf("drive.google.com/Rajakhali");
                        }
                        else if(pekuamouzaV==4)
                        {
                            gotoxy(67,24);
                            printf("Your document-link of Hoanak is given below");
                            gotoxy(67,25);
                            printf("drive.google.com/Hoanak");
                        }

                    }
                    while(pekuamouzaV!=5);
                    ///manepekua
                }
                else if(Coxthana==4)
                {
                    system("cls");
                    ///maneteknaf

                    int tekmouza;
                    do
                    {

                        tekmouza=teknafermouza();
                        if(tekmouza==1)
                        {
                            gotoxy(67,24);
                            printf("Your document-link of Sabrang is given below");
                            gotoxy(67,25);
                            printf("drive.google.com/Sabrang");
                        }
                        else if(tekmouza==2)
                        {
                            gotoxy(67,24);
                            printf("Your document-link of Shah Parir Dail is given below");
                            gotoxy(67,25);
                            printf("drive.google.com/Shahparirdail");
                        }
                        else if(tekmouza==3)
                        {
                            gotoxy(67,24);
                            printf("Your document-link of Boro Dail is given below");
                            gotoxy(67,25);
                            printf("drive.google.com/borodail");
                        }
                        else if(tekmouza==4)
                        {
                            gotoxy(67,24);
                            printf("Your document-link of Uttar Hnila is given below");
                            gotoxy(67,25);
                            printf("drive.google.com/uttarhnila");
                        }

                    }
                    while(tekmouza!=5);
                }

            }
            while (Coxthana!=5);
        }


        else if(zila==3)
        {

            int Noakhalithana;
            do
            {

                Noakhalithana=noakhaliupzilaorthana();
                if(Noakhalithana==1)
                {
                    ///manenoakhalisadar
                    system("cls");
                    int noamouza;
                    do
                    {

                        noamouza=noakhalisadarermouza();
                        if(noamouza==1)
                        {
                            gotoxy(67,24);
                            printf("Your document-link of Ohirampur is given below");
                            gotoxy(67,25);
                            printf("drive.google.com/ohirampur");
                        }
                        else if(noamouza==2)
                        {
                            gotoxy(67,24);
                            printf("Your document-link of Nandanpur is given below");
                            gotoxy(67,25);
                            printf("drive.google.com/nandarnpur");
                        }
                        else if(noamouza==3)
                        {
                            gotoxy(67,24);
                            printf("Your document-link of Jamalpur is given below");
                            gotoxy(67,25);
                            printf("drive.google.com/jamalpur");
                        }
                        else if(noamouza==4)
                        {
                            gotoxy(67,24);
                            printf("Your document-link of Panditpur is given below");
                            gotoxy(67,25);
                            printf("drive.google.com/panditpur");
                        }
                    }
                    while(noamouza!=5);
                }
                else if(Noakhalithana==2)
                {
                    ///manehatia
                    system("cls");
                    int Hatiarmouza;
                    do
                    {

                        Hatiarmouza=hatiarrmouza();
                        if(Hatiarmouza==1)
                        {
                            gotoxy(67,24);
                            printf("Your document-link of Char Isshwar is given below");
                            gotoxy(67,25);
                            printf("drive.google.com/charishwarray");
                        }
                        else if(Hatiarmouza==2)
                        {
                            gotoxy(67,24);
                            printf("Your document-link of Suryamukhi is given below");
                            gotoxy(67,25);
                            printf("drive.google.com/suryamukhir");
                        }
                        else if(Hatiarmouza==3)
                        {
                            gotoxy(67,24);
                            printf("Your document-link of Shunno Char is given below");
                            gotoxy(67,25);
                            printf("drive.google.com/shunnochar");
                        }
                        else if(Hatiarmouza==4)
                        {
                            gotoxy(67,24);
                            printf("Your document-link of Char hair is given below");
                            gotoxy(67,25);
                            printf("drive.google.com/char hair");
                        }
                    }
                    while(Hatiarmouza!=5);
                }
                else if(Noakhalithana==3)
                {
                    ///manebegumganj
                    system("cls");

                    int begumganjMvar;
                    do
                    {
                        begumganjMvar=begumganjermouza();
                        if(begumganjMvar==1)
                        {
                            gotoxy(67,24);
                            printf("Your document-link of Betuabeg is given below");
                            gotoxy(67,25);
                            printf("drive.google.com/betuabeg");
                        }
                        else if(begumganjMvar==2)
                        {
                            gotoxy(67,24);
                            printf("Your document-link of Quari is given below");
                            gotoxy(67,25);
                            printf("drive.google.com/quari");
                        }
                        else if(begumganjMvar==3)
                        {
                            gotoxy(67,24);
                            printf("Your document-link of Mahmudpur is given below");
                            gotoxy(67,25);
                            printf("drive.google.com/mahmudpur");
                        }
                        else if(begumganjMvar==4)
                        {
                            gotoxy(67,24);
                            printf("Your document-link of Bhabahadri is given below");
                            gotoxy(67,25);
                            printf("drive.google.com/Bhababhadri");
                        }
                    }
                    while(begumganjMvar!=5);
                }
                else if(Noakhalithana==4)
                {
                    ///manechatkhil

                    int chatkhilMv;
                    do
                    {
                        chatkhilMv=chatkhilermouza();
                        if(chatkhilMv==1)
                        {
                            gotoxy(67,24);
                            printf("Your document-link of Manikpur is given below");
                            gotoxy(67,25);
                            printf("drive.google.com/manikpur");
                        }
                        else if(chatkhilMv==2)
                        {
                            gotoxy(67,24);
                            printf("Your document-link of Manoharpur is given below");
                            gotoxy(67,25);
                            printf("drive.google.com/manoharpur");
                        }
                        else if(chatkhilMv==3)
                        {
                            gotoxy(67,24);
                            printf("Your document-link of Hiranpur is given below");
                            gotoxy(67,25);
                            printf("drive.google.com/hiranpur");
                        }
                        else if(chatkhilMv==4)
                        {
                            gotoxy(67,24);
                            printf("Your document-link of Pallahidri is given below");
                            gotoxy(67,25);
                            printf("drive.google.com/pallahildri");
                        }

                    }
                    while(chatkhilMv!=5);

                }

            }
            while(Noakhalithana!=5);
        }


        else if(zila==4)
        {

            int Comillarthana;

            do
            {
                Comillarthana=comillarupzilaorthana();
                if(Comillarthana==1)
                {
                    ///chouddagram
                    system("cls");
                    int chouddagramMv;
                    do
                    {
                        chouddagramMv=chouddhagramermouza();
                        if(chouddagramMv==1)
                        {
                            gotoxy(67,24);
                            printf("Your document-link of Katalia is given below");
                            gotoxy(67,25);
                            printf("drive.google.com/katalia");
                        }
                        else if(chouddagramMv==2)
                        {
                            gotoxy(67,24);
                            printf("Your document-link of Dharmapur is given below");
                            gotoxy(67,25);
                            printf("drive.google.com/dharmapur");
                        }
                        else if(chouddagramMv==3)
                        {
                            gotoxy(67,24);
                            printf("Your document-link of Hosenpur is given below");
                            gotoxy(67,25);
                            printf("drive.google.com/hosenpur");
                        }
                        else if(chouddagramMv==4)
                        {
                            gotoxy(67,24);
                            printf("Your document-link of Katalia is given below");
                            gotoxy(67,25);
                            printf("drive.google.com/katalia");
                        }
                    }
                    while(chouddagramMv!=5);
                }
                else if(Comillarthana==2)
                {
                    ///debidwar
                    system("cls");
                    int devidwarMv;
                    do
                    {
                        devidwarMv=debidwarermouza();
                        if(devidwarMv==1)
                        {
                            gotoxy(67,24);
                            printf("Your document-link of Raja Khan Char is given below");
                            gotoxy(67,25);
                            printf("drive.google.com/rajakhanchar");
                        }
                        else if(devidwarMv==2)
                        {
                            gotoxy(67,24);
                            printf("Your document-link of Kaibil is given below");
                            gotoxy(67,25);
                            printf("drive.google.com/kaibil");
                        }
                        else if(devidwarMv==3)
                        {
                            gotoxy(67,24);
                            printf("Your document-link of Gopalnagar is given below");
                            gotoxy(67,25);
                            printf("drive.google.com/gopalnagar");
                        }
                        else if(devidwarMv==4)
                        {
                            gotoxy(67,24);
                            printf("Your document-link of mugsara is given below");
                            gotoxy(67,25);
                            printf("drive.google.com/mugsara");
                        }
                    }
                    while(devidwarMv!=5);
                }
                else if(Comillarthana==3)
                {
                    system("cls");
                    ///homna

                    int homnarMv;
                    do
                    {
                        homnarMv=homnarmouza();
                        if(homnarMv==1)
                        {
                            gotoxy(67,24);
                            printf("Your document-link of Mahishmarihar is given below");
                            gotoxy(67,25);
                            printf("drive.google.com/mahishmarimhar");
                        }
                        else if(homnarMv==2)
                        {
                            gotoxy(67,24);
                            printf("Your document-link of Jay Deb Pur is given below");
                            gotoxy(67,25);
                            printf("drive.google.com/jaydepur");
                        }
                        else if(homnarMv==3)
                        {
                            gotoxy(67,24);
                            printf("Your document-link of Bijaynagar is given below");
                            gotoxy(67,25);
                            printf("drive.google.com/bijaynagar");
                        }
                        else if(homnarMv==4)
                        {
                            gotoxy(67,24);
                            printf("Your document-link of Nayachar is given below");
                            gotoxy(67,25);
                            printf("drive.google.com/nayachar");
                        }
                    }
                    while(homnarMv!=5);
                }
                else if(Comillarthana==4)
                {
                    system("cls");
                    ///laksham

                    int lakshamMv;
                    do
                    {
                        lakshamMv=lakshamermouza();
                        if(lakshamMv==1)
                        {
                            gotoxy(67,24);
                            printf("Your document-link of Kapastala.. is given below");
                            gotoxy(67,25);
                            printf("drive.google.com/kapastalaamhar");
                        }
                        else if(lakshamMv==2)
                        {
                            gotoxy(67,24);
                            printf("Your document-link of Bijwar is given below");
                            gotoxy(67,25);
                            printf("drive.google.com/bijwar");
                        }
                        else if(lakshamMv==3)
                        {
                            gotoxy(67,24);
                            printf("Your document-link of Joyisree is given below");
                            gotoxy(67,25);
                            printf("drive.google.com/Joyisree");
                        }
                        else if(lakshamMv==4)
                        {
                            gotoxy(67,24);
                            printf("Your document-link of Panchpara is given below");
                            gotoxy(67,25);
                            printf("drive.google.com/panchpara");
                        }
                    }
                    while(lakshamMv!=5);
                }

            }

            while(Comillarthana!=5);
        }
    }




    ///ei while zilar menu back korbe
    while (zila != 5);


}

